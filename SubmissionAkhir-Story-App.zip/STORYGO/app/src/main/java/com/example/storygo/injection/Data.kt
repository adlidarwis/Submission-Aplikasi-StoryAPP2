package com.example.storygo.injection

import android.content.Context
import com.example.storygo.data.database.StoryDB
import com.example.storygo.data.retrofit.ConfigApi
import com.example.storygo.repository.UserRepo

object Data {
    fun provideRepository(context: Context): UserRepo {
        val database = StoryDB.getDatabase(context)
        val apiService = ConfigApi.getApiService()
        return UserRepo(database, apiService)
    }
}